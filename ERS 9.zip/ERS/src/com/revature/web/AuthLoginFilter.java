package com.revature.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AuthLoginFilter implements Filter{

	private FilterConfig config;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		System.out.println("Filter Starting...");
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		if(req.getSession().getAttribute("session") != null){
			System.out.println("Filter");
			chain.doFilter(req, resp);
		}else{
			System.out.println("A work appropriate word, for a non-work appropriate exclamation!");
			req.getServletContext()
			.getRequestDispatcher(config.getInitParameter("indexPage"))
			.forward(req, resp);
		}
		
	}

	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
	
}
