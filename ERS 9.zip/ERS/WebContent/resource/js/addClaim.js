/**
 * addClaim.js
 */

$(document).ready(function(){
	$("#amount").keyup(function(){
		var amount = $("#amount").val();
		
		if(amount === null || amount <= 0 || isNaN(amount)){
			$("#amountV").text("Use proper input parameters (i.e. numbers).");
			$("#amountV").css("color","red");
			$("#addBtn").attr("disabled", true);
		}
		else{
			$("#amountV").text("");
			$("#addBtn").attr("disabled", false);
		}
	
		
	})
});



