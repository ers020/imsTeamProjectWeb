/**
 * addClaim.js
 */

$(document).ready(function(){
	$("#amount").keyup(function(){
		var amount = $("#amount").val();

		if(isNaN(amount)){
			$("#amountV").text("You must enter a numeric value.");
			$("#amountV").css("color", "red");
			$("#addBtn").attr("disabled", true);
		}
		else{
			
			$("#amountV").text("");
			$("#addBtn").attr("disabled", false);
			
		}
		
	});
	
});

