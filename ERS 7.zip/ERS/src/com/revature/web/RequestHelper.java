package com.revature.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.app.DataService;
import com.revature.beans.ReimburseBean;
import com.revature.beans.RoleBean;
import com.revature.beans.StatusBean;
import com.revature.beans.TypeBean;
import com.revature.beans.UserBean;
/**
 * Front Controller
 * """"""""""""Controller"""""""""""""""
 * Examples!!!!!!!!!!
 */


public class RequestHelper {
	
	
	public String process(HttpServletRequest request, 
			HttpServletResponse response) {
		System.out.println(request.getRequestURI());
		
		switch(request.getRequestURI()){
			
			case"/ERS/updatePass.do":{
				String password = request.getParameter("password");
				System.out.println(password);
				System.out.println("request helper");
				DataService ds = new DataService();
				ds.updatePassword(password);
				
				return"/login.jsp";
			}
			
			case"/ERS/main.do":{
				
				return"/main.jsp";
				//break;
			}
			
			case"/ERS/login.do":{
				
				String username = request.getParameter("user");
				String password = request.getParameter("pass");
				
				//Validate
				DataService ds = new DataService();	
				
				//Get boolean to compare
				boolean valid = false;
				valid = ds.validateUser(username, password);
				
				if(!valid){
					System.out.println("Invalid");
					return"/index.jsp";
					/*try {
						request.setAttribute("loginFail", "Login failed. Try again.");
						request.getRequestDispatcher("indexPage").forward(request, response);
					} catch (ServletException e) {e.printStackTrace();} 
					catch (IOException e) {e.printStackTrace();}*/
				}else{
				
				
				//Roles 
				List<RoleBean> roles = new ArrayList<RoleBean>();
				roles = ds.fillRolesBean(roles);
				//end Roles
				
				//User
				UserBean user = null;
				user = ds.getUserBean(username, password, user, roles);
				request.getSession().setAttribute("session", user);
				
				/*if(user == null){
					
					try {
						request.setAttribute("loginFail", "Login failed. Try again.");
						request.getRequestDispatcher("indexPage").forward(request, response);
					} catch (ServletException e) {e.printStackTrace();
					} catch (IOException e) {e.printStackTrace();}}
				else{
				request.getSession().setAttribute("session", user);
					try {
						response.sendRedirect("/ERS/secure/main.jsp");
					} catch (IOException e) {e.printStackTrace();}
				}*/
				
				}
				
				return"/main.jsp";
			}
			
			case"/ERS/admin.do":{
				
				//Roles 
				List<RoleBean> roles = new ArrayList<RoleBean>();
				DataService ds = new DataService();
				roles = ds.fillRolesBean(roles);
				//end Roles
				
				//User
				List<UserBean> user = new ArrayList<UserBean>();
				user = ds.fillUserBean(user, roles);
				//end User
				
				//Status
				List<StatusBean> stats = new ArrayList<StatusBean>();
				stats = ds.fillStatusBean(stats);
				//end Status
				
				//Type
				List<TypeBean> type = new ArrayList<TypeBean>();
				type = ds.fillTypeBean(type);
				//end Type	
				
				//Reimbursement
				List<ReimburseBean> reimburseList = new ArrayList<ReimburseBean>();
				reimburseList = ds.fillReimburseBean(user, stats, type, reimburseList);
				request.setAttribute("reimbs", reimburseList);
				
				for(ReimburseBean rb: reimburseList)
				{
					System.out.println(rb.getId());
				}
				
				//request.getSession().setAttribute("session",reimburseList);
				//end Reimbursement
				
				return"/adminView.jsp";
				//break;
			}
			
			case"/ERS/addClaim.do":{
 				
 				DataService ds = new DataService();
 				
 				//get id and other variables
 				int userId = Integer.parseInt(request.getParameter("id"));
 				double amount = Double.parseDouble(request.getParameter("amount"));
 				String desc = request.getParameter("desc");
 				int type = Integer.parseInt(request.getParameter("type"));
 				
 				//get time!
 				Date date = new Date();
 				
 				boolean submitted = false;
 				submitted = ds.inputNewClaim(userId, amount, desc, type, date, submitted);
 				
 				
 				return"/main.jsp";
 			}
			
			case"/ERS/clientClaim.do":{
				
				DataService ds = new DataService();
				
				//Status
				List<StatusBean> stats = new ArrayList<StatusBean>();
				stats = ds.fillStatusBean(stats);
				//end Status
				
				//Type
				List<TypeBean> type = new ArrayList<TypeBean>();
				type = ds.fillTypeBean(type);
				//end Type	
				
				//make available 
				request.setAttribute("stats", stats);
				request.setAttribute("types", type);
				
				return"/clientClaim.jsp";
				//break;
				
			}
			
			case"/ERS/clientView.do":{
				
				DataService ds = new DataService();
				
				UserBean thisUser = null;
				//User - Author
				thisUser = (UserBean) request.getSession().getAttribute("session");
				
				//User - Resolver
				//Roles 
				List<RoleBean> roles = new ArrayList<RoleBean>();
				roles = ds.fillRolesBean(roles);
				//end Roles
				//User
				List<UserBean> user = new ArrayList<UserBean>();
				user = ds.fillUserBean(user, roles);
				//end User
				//end User - Resolver
				
				//Status
				List<StatusBean> stats = new ArrayList<StatusBean>();
				stats = ds.fillStatusBean(stats);
				//end Status
				
				//Type
				List<TypeBean> type = new ArrayList<TypeBean>();
				type = ds.fillTypeBean(type);
				//end Type	
				
				//Reimbursement
				List<ReimburseBean> reimburseList = new ArrayList<ReimburseBean>();
				reimburseList = ds.fillReimburseBeanForIndiviual(thisUser, user, stats, type, reimburseList);
				request.setAttribute("individualReimbs", reimburseList);
				//request.getSession().setAttribute("session",reimburseList);
				//end Reimbursement
				
				
				return"/clientTable.jsp";
				//break;
			}
			
			case"/ERS/logout.do":{
				request.getSession().invalidate();
				return"/logout.jsp";
				//break;
			}
			
			case"/ERS/approveEntry.do":{
				
				DataService ds = new DataService();
				//get resolver information
				UserBean resolver = (UserBean) request.getSession().getAttribute("session");
				
				//get time!
 				Date date = new Date();
				int id = Integer.parseInt(request.getParameter("id"));
				int resolverId = resolver.getId();
				
				
				ds.approveClaim(id, resolverId, date);
				
				return"/main.jsp"; 
				//break;
			}
			
			case"/ERS/denyEntry.do":{
				
				DataService ds = new DataService();
				//get resolver information
				UserBean resolver = (UserBean) request.getSession().getAttribute("session");
				
				//get time!
 				Date date = new Date();
				int id = Integer.parseInt(request.getParameter("id"));
				int resolverId = resolver.getId();
				
				
				ds.denyClaim(id, resolverId, date);
				
				return"/main.jsp"; 
				//break;
			}
			
			default:{
				throw new IllegalArgumentException("Not a valid URI!");
			}
		
		}//end switch
		
	}//end process
	
}//end RequestHelper
