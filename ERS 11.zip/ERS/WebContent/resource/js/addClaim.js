/**
 * addClaim.js
 */

var moneyTest = /^\d*(\.\d{2})$/;
$(document).ready(function(){
	$("#amount").keyup(function(){
		var amount = $("#amount").val();
		var valid = true;
		
		valid = moneyTest.test(amount);
		
		if(amount == null|| amount < 0 || valid == false){
			$("#amountV").text("Invalid numeric entry.");
			$("#amountV").css("color","red");
			$("#addBtn").attr("disabled", true);
		}else{
			$("#amountV").text("");
			$("#addBtn").attr("disabled", false);
		}
	})
});



